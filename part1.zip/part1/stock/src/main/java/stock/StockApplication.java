package stock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import stock.repository.StockRepository;

@SpringBootApplication

public class StockApplication{


	@Autowired
	StockRepository stockRepository;

	public static void main(String[] args) {

		SpringApplication.run(StockApplication.class, args);
	}

}
