package stock.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import stock.repository.StockRepository;

@RestController
public class StockController {
    @Autowired
    StockRepository stockRepository;
    @RequestMapping("/stock/{productNum}")
    public int getNumberOnStock(@PathVariable String productNum){
        return stockRepository.getStock(productNum).getNumberOnStock();
    }
}
