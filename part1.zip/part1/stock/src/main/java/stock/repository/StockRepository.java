package stock.repository;

import org.springframework.stereotype.Repository;
import stock.domain.Stock;

import java.util.ArrayList;
import java.util.List;

@Repository
public class StockRepository {
    List<Stock> stock = new ArrayList<>();
    public StockRepository(){
        stock.add(new Stock(4, "A123"));
        stock.add(new Stock(2, "B314"));
    }

    public Stock getStock(String productNum){
        for (Stock s : stock){
            if (s.getProductNumber().equals(productNum))
                return s;
        }
        return null;
    }
}
