package stock.domain;

public class Stock {
    private int numberOnStock;
    private String productNumber;

    public Stock(int numberOnStock, String productNumber) {
        this.numberOnStock = numberOnStock;
        this.productNumber = productNumber;
    }

    public int getNumberOnStock() {
        return numberOnStock;
    }

    public void setNumberOnStock(int numberOnStock) {
        this.numberOnStock = numberOnStock;
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }
}
