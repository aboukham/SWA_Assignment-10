package products.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class ProductChangeListener {
    @Autowired
    private ProductService productService;

    @JmsListener(destination = "productchange")
    public void receiveMessage(final String productChangeEventString) {

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            ProductChangeEvent productChangeEvent = objectMapper.readValue(productChangeEventString, ProductChangeEvent.class);
            System.out.println("JMS receiver received message:" + productChangeEventString);
            productService.change(productChangeEvent);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
