package products.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import products.domain.Product;
import products.repository.ProductRepository;

import java.util.Collection;

public class ProductService {
    @Autowired
    ProductRepository productRepository;
    @Autowired
    StockFeignClient stockFeignClient;
    public Product getProduct(String productNum){
        int numberOnStock = stockFeignClient.getNumberOnStock(productNum);
        Product p = productRepository.findProduct(productNum);
        p.setNumberOnStock(numberOnStock);
        System.out.println(p);
        return p;
    }
    public Collection<Product> getAllProducts(){
        Collection<Product> products = productRepository.getProducts().values();
        System.out.println(products);
        return products;
    }

    public Product add(Product p){
        int numberOnStock = stockFeignClient.getNumberOnStock(p.getProductNumber());
        p.setNumberOnStock(numberOnStock);
        productRepository.addProduct(p);
        System.out.println(p);
        return p;
    }

    public Product delete(String productNum){
        Product p = productRepository.deleteProduct(productNum);
        System.out.println(p);
        return p;
    }

    public Product update(String productNum, @RequestBody Product p){
        int numberOnStock = stockFeignClient.getNumberOnStock(productNum);
        p.setNumberOnStock(numberOnStock);
        productRepository.addProduct(p);
        System.out.println(p);
        return p;
    }

    @FeignClient(name = "stock-service", url = "http://localhost:8900")
    interface StockFeignClient{
        @RequestMapping("/stock/{productNum}")
        public int getNumberOnStock(@PathVariable("productNum") String productNum);

    }

    public void change(ProductChangeEvent productChangeEvent){
        if (productChangeEvent.getChange().equals("add"))
            add(productChangeEvent.getProduct());
        else if (productChangeEvent.getChange().equals("delete")) {
            delete(productChangeEvent.getProduct().getProductNumber());
        }else
            update(productChangeEvent.getProduct().getProductNumber(), productChangeEvent.getProduct());
    }
}
