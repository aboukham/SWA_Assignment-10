package products.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import products.domain.Product;
import products.repository.ProductRepository;
import products.service.ProductService;

import java.util.Collection;

@RestController
public class productController {
    @Autowired
    ProductService  productService;

    @RequestMapping("/product/{productNum}")
    public ResponseEntity<?> getProduct(@PathVariable("productNum") String productNum){
        Product p = productService.getProduct(productNum);
        return new ResponseEntity<>(p, HttpStatus.OK);
    }

    @RequestMapping("/product")
    public ResponseEntity<?> getAllProducts(){
        Collection<Product> products = productService.getAllProducts();
        return new ResponseEntity<>(products, HttpStatus.OK);
    }


}
