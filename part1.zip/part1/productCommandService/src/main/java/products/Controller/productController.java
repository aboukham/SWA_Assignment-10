package products.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import products.domain.Product;
import products.integration.JmsSender;
import products.repository.ProductRepository;
import products.service.ProductChangeEvent;

@RestController
public class productController {
    @Autowired
    ProductRepository   productRepository;
    @Autowired
    StockFeignClient    stockFeignClient;
    @Autowired
    JmsSender   jmsSender;

    @PostMapping("/product")
    public ResponseEntity<?> add(@RequestBody Product p){
        int numberOnStock = stockFeignClient.getNumberOnStock(p.getProductNumber());
        p.setNumberOnStock(numberOnStock);
        productRepository.addProduct(p);
        System.out.println(p);
        jmsSender.sendMessage(new ProductChangeEvent("add", p));
        return new ResponseEntity<>(p, HttpStatus.OK);
    }

    @PostMapping("/product/{productNum}")
    public ResponseEntity<?> delete(@PathVariable("productNum") String productNum){
        Product p = productRepository.deleteProduct(productNum);
        System.out.println(p);
        jmsSender.sendMessage(new ProductChangeEvent("delete", p));
        return new ResponseEntity<>(p, HttpStatus.OK);
    }

    @RequestMapping("/product/{productNum}")
    public ResponseEntity<?> update(@PathVariable("productNum") String productNum, @RequestBody Product p){
        int numberOnStock = stockFeignClient.getNumberOnStock(productNum);
        p.setNumberOnStock(numberOnStock);
        productRepository.addProduct(p);
        jmsSender.sendMessage(new ProductChangeEvent("update", p));
        System.out.println(p);
        return new ResponseEntity<>(p, HttpStatus.OK);
    }

    @FeignClient(name = "stock-service", url = "http://localhost:8900")
    interface StockFeignClient{
        @RequestMapping("/stock/{productNum}")
        public int getNumberOnStock(@PathVariable("productNum") String productNum);

    }
}
