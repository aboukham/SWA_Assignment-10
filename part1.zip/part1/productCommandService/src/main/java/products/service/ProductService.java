package products.service;

import org.springframework.beans.factory.annotation.Autowired;
import products.repository.ProductRepository;

public class ProductService {
    @Autowired
    ProductRepository productRepository;


}
