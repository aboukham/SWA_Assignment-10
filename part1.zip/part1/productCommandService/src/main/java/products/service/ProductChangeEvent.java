package products.service;

import products.domain.Product;

public class ProductChangeEvent {
    private String change;
    private Product product;


    public ProductChangeEvent(String change, Product product) {
        this.change = change;
        this.product = product;
    }

    public String getChange() {
        return change;
    }

    public Product getProduct() {
        return product;
    }
}
