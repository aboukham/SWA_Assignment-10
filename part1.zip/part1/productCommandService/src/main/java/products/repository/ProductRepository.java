package products.repository;

import org.springframework.stereotype.Repository;
import products.domain.Product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class ProductRepository {
    Map<String, Product> products = new HashMap<>();
    public ProductRepository(){
        products.put("A123", new Product("A123", "Product A"));
        products.put("B314", new Product("B314", "Product B"));
    }

    public void addProduct(Product p){
        products.put(p.getProductNumber(), p);
    }
    public Product deleteProduct(String productNum){
        return products.remove(productNum);

    }



}
